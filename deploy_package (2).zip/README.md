# BIST Bollinger + ATR Tarayıcı — Render'a Dağıtım Rehberi

Bu klasör, uygulamayı **Render** üzerinde herkese açık bir adresle yayınlamak için
hazırlanmış pakettir. Yayınladıktan sonra hem **web** hem **APK** telefonda çalışır.

## Bu pakette neler var
- `app.py` — Flask uygulaması (arayüz + API)
- `server.py` — Render giriş noktası (gunicorn `server:app`)
- `screener_engine.py` — hesaplama motoru (Bollinger squeeze + ATR trailing AL)
- `fetch_data.py` / `fetch_4h.py` — Yahoo'dan veri indirme (günlük / 4 saatlik)
- `bist_tickers.json` — BIST hisse listesi
- `requirements.txt` — bağımlılıklar
- `render.yaml` — Render Blueprint yapılandırması
- `static/` — PWA manifest, ikonlar, service worker

## Yöntem 1: Blueprint ile (en kolay, önerilir)
1. Bu klasörün içeriğini bir **GitHub deposuna** yükleyin.
2. [render.com](https://render.com) → **New → Blueprint** → deponuzu seçin.
3. Render, `render.yaml` dosyasını otomatik okur ve uygulamayı ayağa kaldırır.
4. Size `https://bist-tarayici.onrender.com` gibi bir adres verir.

## Yöntem 2: Web Service (manuel)
1. Depoyu GitHub'a yükleyin.
2. Render → **New → Web Service** → depoyu bağlayın.
3. Ayarlar:
   - **Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn server:app --bind 0.0.0.0:$PORT --workers 1 --timeout 180`
4. **Environment:** Aşağıdakileri ekleyin:
   - `RENDER = 1`
   - `BIST_SKIP_BOOTSTRAP = 0`
5. Deploy edin.

## İlk açılış (önemli)
- Render'ın **free** planında uygulama uykuya geçip uyanınca yavaş açılabilir.
- **İlk açılışta veri otomatik indirilir** (arka planda, ~5 dk). Bu sürede tarama
  kısmi/boş olabilir; tamamlanınca `Tazele` ile güncellenir.
- Taramayı manuel tazelemek için sayfadaki **döngü butonu** veya **Tazele** kullanılır.

## APK'ya adresi girme
1. APK'yı telefona kurun.
2. İlk açılışta gelen ekrana Render adresinizi yazın: `https://bist-tarayici.onrender.com`
3. **Kaydet ve Aç** deyin. Uygulama o adresi yükler ve canlı veriyle tarar.

## Veri güncelleme
- Sayfadaki **döngü butonu** veriyi yeniden çeker ve tarar.
- Render free planında her uyanmada veri tazelenmez; en güncel sonuçlar için
  elle tazeleme önerilir.
