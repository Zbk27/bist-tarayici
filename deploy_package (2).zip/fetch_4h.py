#!/usr/bin/env python3
"""BIST 4 saatlik (4H) veri: 1h çek, 4'erli gruplayarak 4H bar üret. main() olarak çağrılabilir."""
import urllib.request, json, time, os

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data_4h")
os.makedirs(DATA, exist_ok=True)

def fetch(sym):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}.IS?range=3mo&interval=1h"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    r = urllib.request.urlopen(req, timeout=25)
    return json.load(r)

def resample_to_4h(ts, opens, highs, lows, closes, vols, n=4):
    """Her n ardışık barı bir üst zaman dilimi barına birleştirir."""
    out_t, out_o, out_h, out_l, out_c, out_v = [], [], [], [], [], []
    for i in range(0, len(ts), n):
        chunk_t = ts[i:i+n]; chunk_o = opens[i:i+n]; chunk_h = highs[i:i+n]
        chunk_l = lows[i:i+n]; chunk_c = closes[i:i+n]; chunk_v = vols[i:i+n]
        if not chunk_c:
            continue
        cc = [c for c in chunk_c if c is not None]
        if not cc:
            continue
        oo = chunk_o[0] if chunk_o[0] is not None else cc[0]
        hh = max((h for h in chunk_h if h is not None), default=cc[-1])
        ll = min((l for l in chunk_l if l is not None), default=cc[-1])
        vv = sum((v for v in chunk_v if v is not None), 0) or 0
        out_t.append(chunk_t[0]); out_o.append(oo); out_h.append(hh)
        out_l.append(ll); out_c.append(cc[-1]); out_v.append(vv)
    return out_t, out_o, out_h, out_l, out_c, out_v

def save_sym(sym, ts, opens, highs, lows, closes, vols):
    t, o, h, l, c, v = resample_to_4h(ts, opens, highs, lows, closes, vols, 4)
    path = os.path.join(DATA, f"{sym}.csv")
    with open(path, "w") as f:
        f.write("date,open,high,low,close,volume\n")
        for i in range(len(t)):
            f.write(f"{t[i]},{o[i]},{h[i]},{l[i]},{c[i]},{v[i]}\n")
    return len(t)

def main():
    tickers = json.load(open(os.path.join(BASE, "bist_tickers.json")))
    codes = [t[0] for t in tickers]
    done = 0; errors = []; already = 0
    for i, sym in enumerate(codes):
        path = os.path.join(DATA, f"{sym}.csv")
        if os.path.exists(path) and os.path.getsize(path) > 200:
            already += 1
            continue
        for attempt in range(4):
            try:
                j = fetch(sym)
                res = j["chart"]["result"][0]
                ts = res.get("timestamp") or []
                q = res.get("indicators", {}).get("quote", [{}])[0]
                opens = q.get("open") or []; highs = q.get("high") or []
                lows = q.get("low") or []; closes = q.get("close") or []
                vols = q.get("volume") or []
                save_sym(sym, ts, opens, highs, lows, closes, vols)
                done += 1
                break
            except Exception as ex:
                if attempt == 3:
                    errors.append((sym, str(ex)))
                else:
                    time.sleep(1.5*(attempt+1))
        if (done+already) % 25 == 0:
            print(f"progress: {done+already}/{len(codes)}", flush=True)
        time.sleep(0.2)
    print(f"DONE. new={done}, cached={already}, errors={len(errors)}", flush=True)
    return done

if __name__ == "__main__":
    main()
