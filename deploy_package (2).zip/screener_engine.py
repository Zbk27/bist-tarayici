#!/usr/bin/env python3
"""BIST Bollinger Squeeze + ATR Trailing AL tarayıcı hesaplama motoru."""
import math, os, json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE_DIR, "data")
DATA_4H = os.path.join(BASE_DIR, "data_4h")

# ------------------------- ATR / ATR-TRAILING -------------------------
def atr(highs, lows, closes, period):
    n = len(closes)
    tr = [0.0] * n
    for i in range(1, n):
        tr[i] = max(highs[i]-lows[i], abs(highs[i]-closes[i-1]), abs(lows[i]-closes[i-1]))
    tr[0] = highs[0]-lows[0]
    out = [0.0]*n
    if n == 0:
        return out
    s = sum(tr[1:period+1])
    out[period] = s/period
    for i in range(period+1, n):
        out[i] = (out[i-1]*(period-1)+tr[i])/period
    # fill leading zeros with simple average as best effort
    for i in range(1, min(period, n)):
        out[i] = sum(tr[1:i+1])/i
    return out

def atr_trailing_al(highs, lows, closes):
    """Fast Trail (AF1=0.5) vs Slow Trail (AF2=1.3), AL = crossover(Trail1, Trail2)."""
    n = len(closes)
    ap1, ap2 = 5, 5
    af1, af2 = 0.5, 1.3
    atr5 = atr(highs, lows, closes, 5)
    t1 = [0.0]*n
    t2 = [0.0]*n
    prev_t1, prev_t2 = 0.0, 0.0
    for i in range(n):
        sc = closes[i]
        sl1 = af1*atr5[i]
        if i == 0:
            t1[i] = sc
            t2[i] = sc
        else:
            if sc > prev_t1:
                base = sc - sl1
            else:
                base = sc + sl1
            if sc < prev_t1 and closes[i-1] < prev_t1:
                t1[i] = min(prev_t1, sc+sl1)
            else:
                if sc > prev_t1 and closes[i-1] > prev_t1:
                    t1[i] = max(prev_t1, sc-sl1)
                else:
                    t1[i] = base
            sl2 = af2*atr5[i]
            if sc > prev_t2:
                base2 = sc - sl2
            else:
                base2 = sc + sl2
            if sc < prev_t2 and closes[i-1] < prev_t2:
                t2[i] = min(prev_t2, sc+sl2)
            else:
                if sc > prev_t2 and closes[i-1] > prev_t2:
                    t2[i] = max(prev_t2, sc-sl2)
                else:
                    t2[i] = base2
        prev_t1, prev_t2 = t1[i], t2[i]
    # crossover Trail1 over Trail2 (buy)
    al = False
    sat = False
    for i in range(1, n):
        if t1[i] > t2[i] and t1[i-1] <= t2[i-1]:
            al = True
            al_bar = i
    # find LAST buy crossover index
    last_al_idx = None
    for i in range(1, n):
        if t1[i] > t2[i] and t1[i-1] <= t2[i-1]:
            last_al_idx = i
    return t1, t2, last_al_idx

# ------------------------- BOLLINGER SQUEEZE -------------------------
def bollinger_bbw(closes, period=20, mult=2.0):
    n = len(closes)
    mid = [0.0]*n
    up = [0.0]*n
    low = [0.0]*n
    bbw = [0.0]*n
    for i in range(period-1, n):
        w = closes[i-period+1:i+1]
        m = sum(w)/period
        var = sum((x-m)**2 for x in w)/period
        sd = math.sqrt(var)
        mid[i] = m
        up[i] = m + mult*sd
        low[i] = m - mult*sd
        if mid[i] != 0:
            bbw[i] = (up[i]-low[i])/mid[i]*100
    return mid, up, low, bbw

def percentile_rank(value, series):
    """% of historical series values <= value (0..1). Lower = more squeezed."""
    if not series:
        return 0.5
    below = sum(1 for v in series if v <= value)
    return below/len(series)

def squeeze_state(bbw, i, lookback=250, squeeze_pctl=0.15, ext_pctl=0.03,
                  close=None, low=None, high=None, up=None, lowband=None):
    """Classify current bar state.
    p (percentile): 0 = çok dar (sıkışık), 1 = çok geniş.
    Band kırılımı (close > üst band veya < alt band) üstünlük taşır.
    """
    if i < 20 or bbw[i] <= 0:
        return "N/A", None
    hist = [bbw[j] for j in range(max(0, i-lookback), i) if bbw[j] > 0]
    p = percentile_rank(bbw[i], hist)  # 0 = dar, 1 = geniş
    dur = 0
    if hist:
        avg = sum(hist)/len(hist)
        j = i
        while j >= 0 and bbw[j] < avg and bbw[j] > 0:
            dur += 1
            j -= 1
    squeezed = p <= squeeze_pctl
    # Bant kırılımı / breakout
    if up is not None and lowband is not None and close is not None and i < len(up):
        if close[i] > up[i] and squeezed:
            return "Üst Bant Kırılımı (Sweet)", p
        if close[i] < lowband[i] and squeezed:
            return "Alt Bant Kırılımı", p
        if close[i] > up[i]:
            return "Üst Bant Kırılımı", p
        if close[i] < lowband[i]:
            return "Alt Bant Kırılımı", p
    if p <= ext_pctl:
        return "Ekstrem Daralma", p
    if p <= squeeze_pctl:
        return "Daralma", p
    if p >= 0.80:
        return "Yay", p
    return "Nötr / Dalgalanma", p

def load_symbol(sym, tf="D"):
    folder = DATA if tf == "D" else DATA_4H
    path = os.path.join(folder, f"{sym}.csv")
    if not os.path.exists(path):
        return None
    dates, opens, highs, lows, closes, vols = [], [], [], [], [], []
    with open(path) as f:
        next(f)
        for line in f:
            parts = line.strip().split(",")
            if len(parts) < 6:
                continue
            try:
                dt, o, h, l, c, v = int(parts[0]), float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4]), float(parts[5])
            except ValueError:
                continue
            if c == 0:
                continue
            dates.append(dt); opens.append(o); highs.append(h); lows.append(l); closes.append(c); vols.append(v)
    return dates, opens, highs, lows, closes, vols

def chart_series(sym, tf="D", bars=200):
    """Grafik çizimi için son `bars` barlık serileri döndürür."""
    d = load_symbol(sym, tf)
    if not d or len(d[0]) < 30:
        return None
    dates, opens, highs, lows, closes, vols = d
    full_n = len(closes)
    start = max(0, full_n - bars)
    dates = dates[start:]; opens = opens[start:]; highs = highs[start:]
    lows = lows[start:]; closes = closes[start:]; vols = vols[start:]
    mid, up, low, bbw = bollinger_bbw(closes, 20, 2.0)
    t1, t2, _ = atr_trailing_al(highs, lows, closes)
    n = len(closes)  # dilimlenmiş uzunluk
    # AL / SAT krossover noktalarını bul (dilimlenmiş seriler üzerinde)
    buys = []; sells = []
    buy_info = []  # her AL noktası için %B ve büzülme bilgisi
    for i in range(1, n):
        if t1[i] > t2[i] and t1[i-1] <= t2[i-1]:
            buys.append(i)
            # o bar için %B ve büzülme
            pctB = (closes[i] - low[i])/(up[i]-low[i])*100 if up[i] != low[i] else 50.0
            hist = [bbw[j] for j in range(max(0, i-250), i) if bbw[j] > 0]
            p = percentile_rank(bbw[i], hist) if hist else 0.5
            buy_info.append({
                "idx": i,
                "pctB": round(pctB, 1),
                "sq": round((1-p)*100, 1),   # büzülme % (yüksek = daha dar)
            })
        if t1[i] < t2[i] and t1[i-1] >= t2[i-1]:
            sells.append(i)
    return {
        "sym": sym, "tf": tf,
        "dates": dates,
        "close": [round(c, 4) for c in closes],
        "low": [round(x, 4) for x in lows],
        "high": [round(x, 4) for x in highs],
        "upper": [round(x, 4) if x else None for x in up],
        "mid": [round(x, 4) if x else None for x in mid],
        "lower": [round(x, 4) if x else None for x in low],
        "trail1": [round(x, 4) for x in t1],
        "trail2": [round(x, 4) for x in t2],
        "volume": vols,
        "buys": buys,
        "buy_info": buy_info,
        "sells": sells,
    }

def analyze_symbol(sym, name, tf="D"):
    d = load_symbol(sym, tf)
    if not d or len(d[0]) < 30:
        return None
    dates, opens, highs, lows, closes, vols = d
    n = len(closes)
    mid, up, low, bbw = bollinger_bbw(closes, 20, 2.0)
    t1, t2, last_al_idx = atr_trailing_al(highs, lows, closes)
    i = n - 1
    last = closes[i]
    prev = closes[i-1] if i >= 1 else last
    chg = (last-prev)/prev*100 if prev else 0.0
    bbw_now = bbw[i]
    pctB = (last - low[i])/(up[i]-low[i])*100 if up[i] != low[i] else 50.0
    state, pctl = squeeze_state(bbw, i, close=closes, high=highs, low=lows, up=up, lowband=low)
    # AL sinyali: son bar'da ya da son birkaç bar içinde crossover oldu mu?
    al_signal = (last_al_idx is not None) and (i - last_al_idx <= 2)
    al_bars_ago = (i - last_al_idx) if last_al_idx is not None else None
    # trend yönü
    trend_up = t1[i] > t2[i]
    return {
        "sym": sym, "name": name, "price": last, "chg": chg,
        "bbw": bbw_now, "squeeze_pct": (1-pctl)*100 if pctl is not None else None,
        "pctB": pctB, "state": state, "al": al_signal, "al_bars_ago": al_bars_ago,
        "trend_up": trend_up, "t1": t1[i], "t2": t2[i],
        "vol": vols[i] if i < len(vols) else 0,
    }

if __name__ == "__main__":
    # test
    r = analyze_symbol("THYAO", "THY")
    print(r)
