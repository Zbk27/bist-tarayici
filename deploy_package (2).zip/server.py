#!/usr/bin/env python3
"""Render/üretim giriş noktası.
İlk çalıştırmada veri klasörleri boşsa otomatik olarak Yahoo'dan veri çeker.
gunicorn 'server:app' şeklinde import edilir.
"""
import os
import threading
import app as appmod

app = appmod.app  # gunicorn 'server:app' ile bunu kullanır

def bootstrap():
    """Veri yoksa arka planda indir; indirme bittikten sonra taramalar tam veriyle çalışır."""
    def _fetch():
        try:
            import fetch_data
            import fetch_4h
            if not os.path.isdir("data") or not os.listdir("data"):
                fetch_data.main()
            if not os.path.isdir("data_4h") or not os.listdir("data_4h"):
                fetch_4h.main()
            appmod.run_scan("D")
            appmod.run_scan("4H")
        except Exception as e:
            print("Bootstrap veri indirme hatası:", e)
    threading.Thread(target=_fetch, daemon=True).start()

# Render'da tek worker'da veri hazırlığı
if os.environ.get("RENDER") == "1" and not os.environ.get("BIST_SKIP_BOOTSTRAP"):
    bootstrap()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5050)), debug=False)
