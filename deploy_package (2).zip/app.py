#!/usr/bin/env python3
"""BIST Bollinger Squeeze + ATR AL Tarayıcı - Web uygulaması."""
import json, os, time, threading
from flask import Flask, jsonify, render_template_string, request
import screener_engine as engine

app = Flask(__name__)
CACHE_FILE = "scan_cache.json"
CACHE_FILE_4H = "scan_cache_4h.json"
LAST_RESULTS = {}
LAST_TF = "D"

def data_folder(tf):
    return "data_4h" if tf == "4H" else "data"

def run_scan(tf="D"):
    global LAST_RESULTS, LAST_TF
    folder = data_folder(tf)
    if not os.path.isdir(folder):
        return []
    tickers = json.load(open("bist_tickers.json"))
    results = []
    for sym, name in tickers:
        try:
            r = engine.analyze_symbol(sym, name, tf)
            if r:
                results.append(r)
        except Exception:
            continue
    cache = CACHE_FILE_4H if tf == "4H" else CACHE_FILE
    json.dump(results, open(cache, "w"), ensure_ascii=False)
    LAST_RESULTS[tf] = results
    LAST_TF = tf
    return results

@app.route("/")
def index():
    return render_template_string(HTML)

@app.route("/api/scan")
def api_scan():
    tf = request.args.get("tf", "D")
    if tf not in ("D", "4H"):
        tf = "D"
    if request.args.get("refresh"):
        results = run_scan(tf)
    else:
        global LAST_RESULTS
        if tf in LAST_RESULTS and LAST_RESULTS[tf]:
            results = LAST_RESULTS[tf]
        else:
            cache = CACHE_FILE_4H if tf == "4H" else CACHE_FILE
            if os.path.exists(cache):
                results = json.load(open(cache))
                LAST_RESULTS[tf] = results
            else:
                results = run_scan(tf)
    return jsonify({
        "count": len(results),
        "tf": tf,
        "results": results,
        "ts": time.strftime("%d.%m.%Y %H:%M:%S"),
    })

@app.route("/api/chart")
def api_chart():
    sym = request.args.get("sym", "").strip().upper()
    tf = request.args.get("tf", "D")
    if tf not in ("D", "4H"):
        tf = "D"
    if not sym:
        return jsonify({"error": "sym gerekli"}), 400
    d = engine.chart_series(sym, tf)
    if not d:
        return jsonify({"error": "veri yok"}), 404
    return jsonify(d)

@app.route("/api/status")
def api_status():
    total = len(json.load(open("bist_tickers.json")))
    have_d = len([f for f in os.listdir("data") if f.endswith(".csv")]) if os.path.isdir("data") else 0
    have_4h = len([f for f in os.listdir("data_4h") if f.endswith(".csv")]) if os.path.isdir("data_4h") else 0
    return jsonify({"total": total, "daily": have_d, "h4": have_4h})

HTML = """
<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#0d1117">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="BIST Tarayıcı">
<link rel="manifest" href="/static/manifest.webmanifest">
<link rel="apple-touch-icon" href="/static/icons/icon-192.png">
<link rel="icon" type="image/png" href="/static/icons/icon-192.png">
<title>BIST Bollinger Squeeze + ATR AL Tarayıcı</title>
<style>
  :root{
    --bg:#0a0e14; --card:#131a24; --card2:#0f1620; --border:#223040; --txt:#e6edf3;
    --muted:#7d8ea3; --green:#2fd06b; --red:#ff5b57; --blue:#4aa3ff; --yellow:#f5b544;
    --teal:#22d3ee; --purple:#a78bfa; --grad1:#22d3ee; --grad2:#4aa3ff;
  }
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  html,body{margin:0;height:100%}
  body{font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:var(--txt)}
  .app{max-width:560px;margin:0 auto;min-height:100%;padding-bottom:72px;position:relative}
  /* ---- Üst bar ---- */
  .topbar{position:sticky;top:0;z-index:20;background:linear-gradient(180deg,rgba(13,17,23,.98),rgba(13,17,23,.9));
    backdrop-filter:blur(10px);border-bottom:1px solid var(--border);padding:12px 14px}
  .topbar-row{display:flex;align-items:center;gap:10px}
  .logo{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--grad1),var(--grad2));
    display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:#04222a;flex:0 0 auto}
  .brand{flex:1;min-width:0}
  .brand h1{font-size:16px;margin:0;font-weight:700;letter-spacing:.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .brand .sub{color:var(--muted);font-size:11px;margin-top:1px}
  .refresh-btn{background:linear-gradient(135deg,var(--grad1),var(--grad2));border:none;color:#04222a;
    width:38px;height:38px;border-radius:10px;font-size:18px;cursor:pointer;font-weight:800;flex:0 0 auto}
  .seg{display:flex;background:var(--card);border:1px solid var(--border);border-radius:10px;overflow:hidden;margin-top:10px}
  .segbtn{flex:1;padding:10px 6px;font-size:13px;font-weight:600;cursor:pointer;color:var(--muted);text-align:center;transition:.2s}
  .segbtn.active{background:linear-gradient(135deg,rgba(34,211,238,.2),rgba(74,163,255,.2));color:#fff}
  /* ---- İstatistik kartları ---- */
  .statrow{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:12px 14px 4px}
  .stat{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:10px 6px;text-align:center}
  .stat b{font-size:19px;display:block;line-height:1.2}
  .stat small{font-size:10px;color:var(--muted);display:block;margin-top:2px}
  .stat.alx b{color:var(--green)}
  /* ---- Arama & filtre ---- */
  .filters{padding:10px 14px;display:flex;gap:8px;align-items:center}
  .search{flex:1;background:var(--card);border:1px solid var(--border);border-radius:10px;color:var(--txt);
    padding:11px 12px;font-size:14px;outline:none}
  .search:focus{border-color:var(--teal)}
  select{background:var(--card);color:var(--txt);border:1px solid var(--border);border-radius:10px;padding:11px 8px;font-size:13px}
  /* ---- Listeler ---- */
  .list{padding:4px 14px}
  .section-title{font-size:13px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;margin:12px 2px 8px}
  .stock-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:12px;
    display:flex;align-items:center;gap:12px;margin-bottom:9px;cursor:pointer;transition:transform .1s,border-color .2s}
  .stock-card:active{transform:scale(.985)}
  .stock-card.alx{border-color:rgba(47,208,107,.45);box-shadow:0 0 0 1px rgba(47,208,107,.15),0 4px 20px rgba(47,208,107,.06)}
  .sc-ic{width:44px;height:44px;border-radius:11px;display:flex;align-items:center;justify-content:center;
    font-weight:800;font-size:13px;flex:0 0 auto;background:#1a2534;color:var(--blue)}
  .sc-bd{flex:1;min-width:0}
  .sc-name{font-weight:700;font-size:14px;display:flex;align-items:center;gap:6px}
  .sc-full{font-size:11px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .sc-metrics{display:flex;gap:12px;margin-top:6px;font-size:11px;color:var(--muted)}
  .sc-metrics b{color:var(--txt);font-weight:600}
  .sc-right{text-align:right;flex:0 0 auto}
  .sc-price{font-size:16px;font-weight:700}
  .sc-chg{font-size:12px;font-weight:600}
  .up{color:var(--green)} .dn{color:var(--red)}
  .badge{padding:3px 9px;border-radius:12px;font-size:10px;font-weight:700}
  .b-ext{background:rgba(167,139,250,.16);color:#c4b5fd;border:1px solid rgba(167,139,250,.3)}
  .b-sq{background:rgba(74,163,255,.14);color:#8ec5ff;border:1px solid rgba(74,163,255,.3)}
  .b-yay{background:rgba(245,181,68,.14);color:#fcd34d;border:1px solid rgba(245,181,68,.3)}
  .b-notr{background:rgba(125,142,163,.12);color:#a3b0c2;border:1px solid rgba(125,142,163,.25)}
  .b-al{background:var(--green);color:#032a12;border:none}
  .b-ral{background:rgba(125,142,163,.15);color:#8b98a8}
  .pill{display:inline-block;background:var(--card);border:1px solid var(--border);border-radius:20px;
    padding:5px 12px;font-size:11px;color:var(--muted);cursor:pointer;margin:0 4px 6px 0}
  .pill.active{color:#fff;border-color:var(--teal);background:rgba(34,211,238,.18)}
  .pills{padding:2px 14px;display:flex;flex-wrap:wrap}
  .empty{padding:40px 20px;text-align:center;color:var(--muted);font-size:14px}
  .loader{display:none;padding:14px;text-align:center;color:var(--teal);font-weight:600}
  .spinner{display:inline-block;width:18px;height:18px;border:2px solid rgba(34,211,238,.3);border-top-color:var(--teal);
    border-radius:50%;animation:spin .7s linear infinite;vertical-align:middle;margin-right:8px}
  @keyframes spin{to{transform:rotate(360deg)}}
  /* ---- Bottom nav ---- */
  .bottomnav{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:560px;z-index:30;
    background:rgba(15,22,32,.97);backdrop-filter:blur(12px);border-top:1px solid var(--border);
    display:flex;padding:6px 0 calc(6px + env(safe-area-inset-bottom))}
  .navitem{flex:1;text-align:center;padding:6px 2px;color:var(--muted);cursor:pointer;transition:.2s}
  .navitem .ni{font-size:20px;display:block}
  .navitem .nl{font-size:10px;font-weight:600}
  .navitem.active{color:var(--teal)}
  /* ---- Modal ---- */
  .modal{display:none;position:fixed;inset:0;background:rgba(4,8,12,.7);z-index:50;align-items:center;justify-content:center}
  .modal.show{display:flex}
  .modalbox{background:var(--card);border:1px solid var(--border);border-radius:16px;width:min(96vw,560px);
    max-height:92vh;padding:14px;overflow:auto;box-shadow:0 20px 60px rgba(0,0,0,.5)}
  .modalhead{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
  #mTitle{font-size:17px;font-weight:700}
  .mclose{background:var(--card2);border:1px solid var(--border);color:var(--muted);width:30px;height:30px;
    border-radius:9px;cursor:pointer;font-size:14px}
  #chartwrap svg{width:100%;height:auto;display:block}
  .legend{display:flex;gap:10px;flex-wrap:wrap;font-size:11px;margin-bottom:8px;color:var(--muted)}
  .legend i{display:inline-block;width:12px;height:3px;vertical-align:middle;margin-right:4px;border-radius:2px}
  /* ---- Hakkında ---- */
  .about{padding:8px 14px}
  .about-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:16px;margin-bottom:10px}
  .about-card h3{margin:0 0 8px;font-size:15px}
  .about-card p{margin:6px 0;font-size:13px;color:var(--muted);line-height:1.5}
  .about-card b{color:var(--txt)}
  .note{color:var(--muted);font-size:11px;margin:14px 14px;line-height:1.6}
  @media (min-width:641px){
    .app{max-width:720px}
    .statrow{grid-template-columns:repeat(4,1fr)}
  }
</style>
</head>
<body>
<div class="app">
  <!-- Üst bar -->
  <div class="topbar">
    <div class="topbar-row">
      <div class="logo">B+</div>
      <div class="brand">
        <h1>BIST Bollinger <span style="color:var(--teal)">+</span> ATR</h1>
        <div class="sub" id="datastatus">Veri yükleniyor...</div>
      </div>
      <button class="refresh-btn" onclick="scan(true)" title="Tazele">&#8635;</button>
      <button id="installBtn" onclick="installApp()" style="display:none;background:var(--green);color:#032a12;border:none;border-radius:10px;padding:8px 10px;font-size:12px;font-weight:700">Kur</button>
    </div>
    <div class="seg">
      <span class="segbtn active" id="tfD" onclick="setTF('D')">Günlük</span>
      <span class="segbtn" id="tf4H" onclick="setTF('4H')">4 Saatlik</span>
    </div>
  </div>

  <!-- Sayfa: Ana -->
  <div id="page-main">
    <div class="statrow">
      <div class="stat" id="statTotal"></div>
      <div class="stat" id="statExt"></div>
      <div class="stat" id="statAl"></div>
      <div class="stat alx" id="statAlExt"></div>
    </div>
    <div class="filters">
      <input class="search" id="q" placeholder="Hisse ara (THYAO, GARAN...)">
      <select id="sort" onchange="render()">
        <option value="alx">Öne çıkan</option>
        <option value="state">Duruma göre</option>
        <option value="al">AL sinyali önce</option>
        <option value="sk">Ekstrem daralma önce</option>
        <option value="chg">Değişim</option>
        <option value="price">Fiyat</option>
      </select>
    </div>
    <div class="pills" id="pills"></div>
    <div class="loader" id="loader"><span class="spinner"></span>Tarama yapılıyor...</div>
    <div class="list" id="list"></div>
  </div>

  <!-- Sayfa: Hakkında -->
  <div id="page-about" style="display:none">
    <div class="about">
      <div class="about-card">
        <h3>&#129297; Nasıl çalışır?</h3>
        <p><b>Bollinger Squeeze:</b> Bollinger bantları (20, 2.0) genişlik bakımından son 250 bara göre
        <b>ekstrem daralma</b> gösterdiğinde, fiyat sıkışma sonrası patlama potansiyeli taşır.</p>
        <p><b>ATR Trailing:</b> Hızlı (0.5) ve yavaş (1.3) iz çizgileri; <b>fast trail, slow trail'i
        yukarı kestiğinde AL</b> sinyali üretilir.</p>
        <p><b>Hedef:</b> Ekstrem daralma <b>ve</b> AL sinyali birlikte görülen hisseler öne çıkar.</p>
      </div>
      <div class="about-card">
        <h3>&#128200; Gösterge açıklamaları</h3>
        <p><b>BBW:</b> Bant genişliği (%) — üst-alt bant aralığı.</p>
        <p><b>Büzülme %:</b> Bant genişliğinin geçmişe göre ne kadar daraldığı (yüksek = sıkışık).</p>
        <p><b>%B:</b> Fiyatın bant içindeki konumu (0 alt / 100 üst).</p>
        <p><b>AL + Ekstrem:</b> İki sinyalin aynı anda aktif olduğu en güçlü kombinasyon.</p>
      </div>
      <div class="about-card">
        <h3>&#9888;&#65039; Uyarı</h3>
        <p>Veriler gecikmeli Yahoo Finance kaynağındandır, eğitim amaçlıdır. Bu uygulama <b>yatırım
        tavsiyesi değildir.</b></p>
      </div>
    </div>
  </div>

  <!-- Bottom Nav -->
  <div class="bottomnav">
    <div class="navitem active" id="nav-main" onclick="goto('main')">
      <span class="ni">&#128202;</span><span class="nl">Tarama</span>
    </div>
    <div class="navitem" id="nav-alerts" onclick="goto('alerts')">
      <span class="ni">&#128276;</span><span class="nl">Sinyaller</span>
    </div>
    <div class="navitem" id="nav-about" onclick="goto('about')">
      <span class="ni">&#8505;</span><span class="nl">Bilgi</span>
    </div>
  </div>

  <!-- Grafik Modal -->
  <div class="modal" id="modal" onclick="if(event.target===this)closeChart()">
    <div class="modalbox">
      <div class="modalhead">
        <span id="mTitle">—</span>
        <button class="mclose" onclick="closeChart()">&#10005;</button>
      </div>
      <div class="seg" style="margin-bottom:10px">
        <span class="segbtn" id="cD" onclick="chartTF('D')">Günlük</span>
        <span class="segbtn" id="c4H" onclick="chartTF('4H')">4 Saatlik</span>
      </div>
      <div id="chartwrap">Yükleniyor...</div>
    </div>
  </div>
</div>

<script>
let ALL = [];
let TF = 'D';
let page = 'main';

function goto(p){
  page = p;
  document.getElementById('page-main').style.display = p==='main'||p==='alerts' ? '' : 'none';
  document.getElementById('page-about').style.display = p==='about' ? '' : 'none';
  document.getElementById('nav-main').className = 'navitem' + (p==='main'?' active':'');
  document.getElementById('nav-alerts').className = 'navitem' + (p==='alerts'?' active':'');
  document.getElementById('nav-about').className = 'navitem' + (p==='about'?' active':'');
  if(p==='alerts') renderAlerts(); else render();
}

function fmtP(v){ if(v===null||v===undefined||isNaN(v)) return '—'; return v.toFixed(2); }

function setTF(tf){
  TF = tf;
  document.getElementById('tfD').className = tf==='D'?'segbtn active':'segbtn';
  document.getElementById('tf4H').className = tf==='4H'?'segbtn active':'segbtn';
  scan(false);
}

async function status(){
  try{
    const r = await fetch('/api/status');
    const d = await r.json();
    document.getElementById('datastatus').textContent = `Günlük ${d.daily}/${d.total} • 4S ${d.h4}/${d.total} hisse`;
  }catch(e){}
}

async function scan(refresh){
  const loader=document.getElementById('loader');
  loader.style.display='block';
  try{
    const url = (refresh?'/api/scan?refresh=1&tf=':'/api/scan?tf=')+TF;
    const r = await fetch(url);
    const d = await r.json();
    ALL = d.results;
    document.getElementById('statTotal').innerHTML = `<b>${d.count}</b><small>Hisse</small>`;
    render();
    if(page==='alerts') renderAlerts();
  }catch(e){
    loader.innerHTML = '<span>Hata: '+e+'</span>';
  }
  loader.style.display='none';
}

function stateBadge(s){
  if(!s) return '<span class="badge b-notr">—</span>';
  const map={'Ekstrem Daralma':['b-ext','Ekstrem Daralma'],'Daralma':['b-sq','Daralma'],
    'Yay':['b-yay','Yay'],'Üst Bant Kırılımı':['b-yay','Üst Kırılım'],
    'Üst Bant Kırılımı (Sweet)':['b-yay','Sweet Spot'],'Alt Bant Kırılımı':['b-notr','Alt Kırılım']};
  const m=map[s]||['b-notr',s];
  return '<span class="badge '+m[0]+'">'+m[1]+'</span>';
}

function cardHTML(x){
  const chg = x.chg>=0?'+'+fmtP(x.chg):fmtP(x.chg);
  return `<div class="stock-card ${x.al && x.state==='Ekstrem Daralma'?'alx':''}" onclick="showChart('${x.sym}')">
    <div class="sc-ic">${x.sym.slice(0,4)}</div>
    <div class="sc-bd">
      <div class="sc-name">${x.sym} ${x.al?'<span class="badge b-al">AL</span>':''}</div>
      <div class="sc-full">${x.name||''}</div>
      <div class="sc-metrics">
        <span>Büz <b>${fmtP(x.squeeze_pct)}%</b></span>
        <span>%B <b>${fmtP(x.pctB)}</b></span>
        <span>BBW <b>${fmtP(x.bbw)}</b></span>
      </div>
    </div>
    <div class="sc-right">
      <div class="sc-price">${fmtP(x.price)}₺</div>
      <div class="sc-chg ${x.chg>=0?'up':'dn'}">${chg}%</div>
      <div style="margin-top:5px">${stateBadge(x.state)}</div>
    </div>
  </div>`;
}

function renderAlerts(){
  const rows = ALL.filter(x=>x.al && x.state==='Ekstrem Daralma');
  let h = `<div class="section-title">&#128276; AL + Ekstrem Daralma</div>`;
  if(!rows.length) h += `<div class="empty">Bu periyotta AL + ekstrem daralma eşleşmesi yok.</div>`;
  rows.forEach(x=>{ h += cardHTML(x); });
  document.getElementById('list').innerHTML = h;
}

function render(){
  if(page==='alerts'){ renderAlerts(); return; }
  const q=(document.getElementById('q').value||'').toUpperCase().trim();
  const sort=document.getElementById('sort').value;
  let rows=ALL.filter(x=>!q || x.sym.includes(q) || (x.name||'').toUpperCase().includes(q));

  const key=(s)=>{ const o={'Ekstrem Daralma':0,'Daralma':1,'Yay':2,'Nötr / Dalgalanma':3}; return o[s]??5; };
  if(sort==='alx') rows.sort((a,b)=> ((b.al&&b.state==='Ekstrem Daralma')?1:0)-((a.al&&a.state==='Ekstrem Daralma')?1:0) || key(a.state)-key(b.state) || (b.squeeze_pct||0)-(a.squeeze_pct||0));
  else if(sort==='state') rows.sort((a,b)=> key(a.state)-key(b.state) || (b.squeeze_pct||0)-(a.squeeze_pct||0));
  else if(sort==='al') rows.sort((a,b)=> (b.al?1:0)-(a.al?1:0) || (b.squeeze_pct||0)-(a.squeeze_pct||0));
  else if(sort==='sk') rows.sort((a,b)=> (a.squeeze_pct||0)-(b.squeeze_pct||0));
  else if(sort==='chg') rows.sort((a,b)=> b.chg-a.chg);
  else rows.sort((a,b)=> b.price-a.price);

  const ext=rows.filter(x=>x.state==='Ekstrem Daralma').length;
  const al=rows.filter(x=>x.al).length;
  const alExt=rows.filter(x=>x.al && x.state==='Ekstrem Daralma').length;
  document.getElementById('statExt').innerHTML = `<b>${ext}</b><small>Ekstrem</small>`;
  document.getElementById('statAl').innerHTML = `<b>${al}</b><small>AL sinyal</small>`;
  document.getElementById('statAlExt').innerHTML = `<b>${alExt}</b><small>AL+Ekstrem</small>`;

  const st=['Ekstrem Daralma','Daralma','Yay','Nötr / Dalgalanma'];
  document.getElementById('pills').innerHTML = st.map(s=>{
    const c=rows.filter(x=>x.state===s).length;
    return `<span class="pill${s==='Ekstrem Daralma'?' active':''}">${s} (${c})</span>`;
  }).join('');

  let h = rows.length ? '' : `<div class="empty">Sonuç yok.</div>`;
  rows.forEach(x=>{ h += cardHTML(x); });
  document.getElementById('list').innerHTML = h;
}

// ---------------- Grafik Modal ----------------
let curSym = null, curTF = 'D';

function showChart(sym){
  curSym = sym; curTF = TF;
  document.getElementById('modal').classList.add('show');
  document.getElementById('cD').className = curTF==='D'?'segbtn active':'segbtn';
  document.getElementById('c4H').className = curTF==='4H'?'segbtn active':'segbtn';
  loadChart();
}
function closeChart(){
  document.getElementById('modal').classList.remove('show');
  curSym = null;
}
function chartTF(tf){
  curTF = tf;
  document.getElementById('cD').className = tf==='D'?'segbtn active':'segbtn';
  document.getElementById('c4H').className = tf==='4H'?'segbtn active':'segbtn';
  loadChart();
}
async function loadChart(){
  const wrap = document.getElementById('chartwrap');
  const title = document.getElementById('mTitle');
  title.textContent = curSym + '  —  ' + (curTF==='4H'?'4 Saatlik':'Günlük');
  wrap.textContent = 'Yükleniyor...';
  try{
    const r = await fetch(`/api/chart?sym=${curSym}&tf=${curTF}`);
    const d = await r.json();
    if(d.error){ wrap.textContent = d.error; return; }
    drawSVG(d, wrap);
  }catch(e){
    wrap.textContent = 'Hata: '+e;
  }
}

function drawSVG(d, wrap){
  const n = d.close.length;
  const W = 560, H = 380, padL = 44, padR = 10, padT = 12, padB = 22;
  const pw = W - padL - padR, ph = H - padT - padB;
  let mn = Infinity, mx = -Infinity;
  [d.close, d.upper, d.lower, d.trail1, d.trail2].forEach(ser=>{
    ser.forEach(v=>{ if(v && !isNaN(v)){ if(v<mn)mn=v; if(v>mx)mx=v; } });
  });
  const span = (mx-mn) || 1;
  const top = mx + span*0.05, bot = mn - span*0.05;
  const X = i => padL + (n<=1?0:(i/(n-1))*pw);
  const Y = v => padT + (top-v)/(top-bot)*ph;
  let s = `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif">`;
  for(let g=0; g<=5; g++){
    const val = top - (top-bot)*g/5;
    const y = Y(val);
    s += `<line x1="${padL}" y1="${y}" x2="${W-padR}" y2="${y}" stroke="#1c2531" stroke-width="1"/>`;
    s += `<text x="${padL-5}" y="${y+3}" fill="#7d8ea3" font-size="9" text-anchor="end">${val.toFixed(1)}</text>`;
  }
  const xticks = 6;
  for(let g=0; g<xticks; g++){
    const i = Math.round((n-1)*g/(xticks-1));
    const dt = new Date(d.dates[i]*1000).toLocaleDateString('tr-TR',{day:'2-digit',month:'2-digit'});
    s += `<text x="${X(i)}" y="${H-5}" fill="#7d8ea3" font-size="9" text-anchor="middle">${dt}</text>`;
  }
  const line = (ser, color, w=1.4, dash='') => {
    if(!ser || ser.length===0) return '';
    let p = '';
    for(let i=0;i<n;i++){
      const v=ser[i]; if(v==null||isNaN(v)){continue;}
      p += (p?'L':'M') + X(i).toFixed(1) + ' ' + Y(v).toFixed(1) + ' ';
    }
    return `<path d="${p}" fill="none" stroke="${color}" stroke-width="${w}" ${dash?`stroke-dasharray="${dash}"`:''}/>`;
  };
  const pts = (ser) => { const r=[]; for(let i=0;i<n;i++){ const v=ser[i]; if(v!=null&&!isNaN(v)) r.push(i); } return r; };
  if(d.upper && d.lower){
    const ui=pts(d.upper), li=pts(d.lower);
    if(ui.length && li.length){
      let area=`M${X(ui[0])} ${Y(d.upper[ui[0]])}`;
      for(const i of ui) area+=` L${X(i)} ${Y(d.upper[i])}`;
      for(let k=li.length-1;k>=0;k--){ const i=li[k]; area+=` L${X(i)} ${Y(d.lower[i])}`; }
      area+=' Z';
      s += `<path d="${area}" fill="#4aa3ff" fill-opacity="0.07" stroke="none"/>`;
    }
  }
  s += line(d.mid, '#9aa4b2', 1, '');
  s += line(d.upper, '#4aa3ff', 1.1);
  s += line(d.lower, '#4aa3ff', 1.1);
  s += line(d.trail1, '#f5b544', 1.8);
  s += line(d.trail2, '#ff5b57', 1.8);
  s += line(d.close, '#e6edf3', 1.8);

  const vH = 60;
  const vBot = H - padB, vTop = vBot - vH;
  let vmax = 0;
  if(d.volume){ d.volume.forEach(v=>{ if(v>vmax) vmax=v; }); }
  if(d.volume && vmax>0){
    const bw = pw/n, w = Math.max(1, bw*0.65);
    for(let i=0;i<n;i++){
      const v = d.volume[i]; if(!v) continue;
      const hgt = (v/vmax)*vH;
      const x = X(i)-bw/2 + (bw-w)/2;
      const up = i>0 ? (d.close[i]>=d.close[i-1]) : true;
      const y = vTop + (vH-hgt);
      s += `<rect x="${x}" y="${y}" width="${w}" height="${hgt}" fill="${up?'#1f8f4d':'#b03a35'}" fill-opacity="0.5"/>`;
    }
    s += `<line x1="${padL}" y1="${vTop}" x2="${W-padR}" y2="${vTop}" stroke="#223040" stroke-width="1"/>`;
  }

  const buyInfoMap = {};
  if(d.buy_info) d.buy_info.forEach(b=>{ buyInfoMap[b.idx]=b; });
  const mk = (arr, color, dir) => {
    arr.forEach(i=>{
      const x = X(i);
      const price = d.low[i];
      const y = Y(price) + (dir>0 ? 7 : -7);
      const sz = 8;
      if(dir>0){
        s += `<polygon points="${x} ${y} ${x-sz} ${y-sz*1.6} ${x+sz} ${y-sz*1.6}" fill="${color}" stroke="#0a0e14" stroke-width="1"/>`;
      } else {
        s += `<polygon points="${x} ${y} ${x-sz} ${y+sz*1.6} ${x+sz} ${y+sz*1.6}" fill="${color}" stroke="#0a0e14" stroke-width="1"/>`;
      }
      s += `<text x="${x}" y="${dir>0?y-sz*1.9:y+sz*1.9}" fill="${color}" font-size="10" font-weight="700" text-anchor="middle">${dir>0?'AL':'SAT'}</text>`;
      if(dir>0 && buyInfoMap[i]){
        const info = buyInfoMap[i];
        const bx = x, by = y + 16;
        s += `<rect x="${bx-44}" y="${by-8}" width="88" height="14" rx="3" fill="#0a0e14" fill-opacity="0.9" stroke="#223040"/>`;
        s += `<text x="${bx}" y="${by+4}" fill="#c4b5fd" font-size="8" text-anchor="middle">%B ${info.pctB} • Büz ${info.sq}%</text>`;
      }
    });
  };
  if(d.buys)  mk(d.buys,  '#2fd06b', 1);
  if(d.sells) mk(d.sells, '#ff5b57', -1);
  s += '</svg>';

  const lastC = d.close[n-1];
  const leg = `<div class="legend">
    <span><i style="background:#e6edf3"></i>Kapanış ${lastC.toFixed(2)}</span>
    <span><i style="background:#4aa3ff"></i>Bollinger</span>
    <span><i style="background:#f5b544"></i>Fast Trail</span>
    <span><i style="background:#ff5b57"></i>Slow Trail</span>
    <span><i style="background:#2fd06b"></i>AL</span>
    <span><i style="background:#ff5b57"></i>SAT</span>
  </div>`;
  wrap.innerHTML = leg + s;
}

status(); scan(false);
setInterval(status, 10000);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/static/sw.js').catch(()=>{});
  });
}
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const b = document.getElementById('installBtn');
  if(b) b.style.display = 'inline-block';
});
function installApp(){
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  deferredPrompt.userChoice.then(()=>{ deferredPrompt = null; });
}
</script>
</body>
</html>
"""

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5050, debug=False)
