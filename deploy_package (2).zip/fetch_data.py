#!/usr/bin/env python3
"""BIST günlük veri indirme. main() fonksiyonu olarak çağrılabilir."""
import urllib.request, json, time, os

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data")
os.makedirs(DATA, exist_ok=True)

def fetch(sym):
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}.IS?range=1y&interval=1d&events=div%2Csplit"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    r = urllib.request.urlopen(req, timeout=20)
    return json.load(r)

def save_sym(sym, j):
    res = j["chart"]["result"][0]
    ts = res.get("timestamp") or []
    q = res.get("indicators", {}).get("quote", [{}])[0]
    opens = q.get("open") or []
    highs = q.get("high") or []
    lows = q.get("low") or []
    closes = q.get("close") or []
    vols = q.get("volume") or []
    path = os.path.join(DATA, f"{sym}.csv")
    with open(path, "w") as f:
        f.write("date,open,high,low,close,volume\n")
        for i in range(len(ts)):
            o, h, l, c = opens[i], highs[i], lows[i], closes[i]
            v = vols[i] if i < len(vols) else 0
            if c is None:
                continue
            f.write(f"{ts[i]},{o if o is not None else ''},{h if h is not None else ''},{l if l is not None else ''},{c if c is not None else ''},{v if v is not None else ''}\n")
    return len(ts)

def main():
    tickers = json.load(open(os.path.join(BASE, "bist_tickers.json")))
    codes = [t[0] for t in tickers]
    done = 0
    errors = []
    already = 0
    for i, sym in enumerate(codes):
        path = os.path.join(DATA, f"{sym}.csv")
        if os.path.exists(path) and os.path.getsize(path) > 200:
            already += 1
            continue
        for attempt in range(4):
            try:
                j = fetch(sym)
                save_sym(sym, j)
                done += 1
                break
            except Exception as e:
                if attempt == 3:
                    errors.append((sym, str(e)))
                else:
                    time.sleep(1.5 * (attempt + 1))
        if (done + already) % 25 == 0:
            print(f"progress: {done+already}/{len(codes)} (new={done}, cached={already})", flush=True)
        time.sleep(0.25)
    print(f"DONE. fetched new={done}, cached={already}, errors={len(errors)}", flush=True)
    return done

if __name__ == "__main__":
    main()
